package com.example.app_doc_bao_bang_rss;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ListView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReadRSS extends AsyncTask<String, Void, String> {


    CusAdapter cusAdapter;
    ArrayList<Docbao> mangDocBao = new ArrayList<Docbao>();
    ListView listView;
    Context context;

    public ReadRSS(ArrayList<Docbao> mangDocBao, ListView listView, Context context) {
        this.mangDocBao = mangDocBao;
        this.listView = listView;
        this.context = context;
    }

    @Override
    protected String doInBackground(String... strings) {
        StringBuilder content = new StringBuilder();
        try {
            URL url = new URL(strings[0]);
            InputStreamReader inputStreamReader =
                    new InputStreamReader(url.openConnection().getInputStream());

            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                content.append(line);
            }
            bufferedReader.close();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return content.toString();
    }

    @Override
    protected void onPostExecute(String s) {


        XMLDOMParser parser = new XMLDOMParser();
        Document document = parser.getDocument(s);

        NodeList nodeList = document.getElementsByTagName("item");


        String hinhanh = "";
        String title = "";
        String link = "";
        String pubDate = "";
        mangDocBao.clear();
//            Toast.makeText(getContext(), "kaka" + nodeList.getLength(), Toast.LENGTH_SHORT).show();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Element element = (Element) nodeList.item(i);

            NodeList nodeListDescription = element.getElementsByTagName("description");
            String cData =
                    nodeListDescription.item(0).getTextContent();
            Pattern p = Pattern.compile("<img[^>]+src\\s*=\\s*['\"]([^'\"]+)['\"][^>]*>");
            Matcher matcher = p.matcher(cData);
            if (matcher.find()) {
                hinhanh = matcher.group(1);
                Log.d("hinhanh: ", hinhanh);
            }


            NodeList Title = element.getElementsByTagName("title");
            title = Title.item(0).getTextContent();


            NodeList Link = element.getElementsByTagName("link");
            link = Link.item(0).getTextContent();

            NodeList PubDate = element.getElementsByTagName("pubDate");
            pubDate = PubDate.item(0).getTextContent();
            Calendar c = Calendar.getInstance();
            int date = c.get(Calendar.DATE);
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);
            String[] output = pubDate.split(" ");
            int tmp = Integer.parseInt(output[1]);
            date = date - tmp;
            String[] output2 = output[4].split(":");
            tmp = Integer.parseInt(output2[0]);
            hour = hour - tmp;
            tmp = Integer.parseInt(output2[1]);
            minute = minute - tmp;


            if(hour >0)
                pubDate = ""+ hour + " hours ago";
            else if(hour == 0)
                pubDate = ""+ minute + " minutes ago";

            mangDocBao.add(new Docbao(title, link, hinhanh, pubDate));
        }
        cusAdapter = new CusAdapter(context, android.R.layout.simple_expandable_list_item_1
                , mangDocBao);
        if (cusAdapter != null)
            listView.setAdapter(cusAdapter);
        super.onPostExecute(s);

    }

    public ArrayList<Docbao> getMangDocBao() {
        return mangDocBao;
    }

    public void setMangDocBao(ArrayList<Docbao> mangDocBao) {
        this.mangDocBao = mangDocBao;
    }
}
