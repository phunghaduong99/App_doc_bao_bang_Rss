package com.example.app_doc_bao_bang_rss.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.fragment.app.Fragment;

import com.example.app_doc_bao_bang_rss.CusAdapter;
import com.example.app_doc_bao_bang_rss.Docbao;
import com.example.app_doc_bao_bang_rss.Main2Activity;
import com.example.app_doc_bao_bang_rss.R;

import java.util.ArrayList;

public class Tab1 extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private String link1;
    private String link2;
    private String link3;
    private int tab;
    CusAdapter cusAdapter;
    ArrayList<Docbao> mangDocBao = new ArrayList<Docbao>();
    ListView listView;
    Context context;

    Spinner spinner;

    public Tab1( String link1, String link2, String link3, int tab) {
        this.link1 = link1;
        this.link2 = link2;
        this.link3 = link3;
        this.tab = tab;
    }

    public Tab1() {
        // Required empty public constructor
    }


    public static Tab1 newInstance(String param1, String param2) {
        Tab1 fragment = new Tab1();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_tab1,
                container, false);
        switch (tab){
            case 1:
                 rootView = inflater.inflate(R.layout.fragment_tab1,
                        container, false);
                 spinner = rootView.findViewById(R.id.spinner1);
                 listView = rootView.findViewById(R.id.listView1);
            case 2:
                rootView = inflater.inflate(R.layout.fragment_tab2,
                        container, false);
                spinner = rootView.findViewById(R.id.spinner2);
                listView = rootView.findViewById(R.id.listView2);
            case 3:
                rootView = inflater.inflate(R.layout.fragment_tab3,
                        container, false);
                spinner = rootView.findViewById(R.id.spinner3);
                listView = rootView.findViewById(R.id.listView3);
            case 4:
                rootView = inflater.inflate(R.layout.fragment_tab4,
                        container, false);
                spinner = rootView.findViewById(R.id.spinner4);
                listView = rootView.findViewById(R.id.listView4);
            case 5:
                rootView = inflater.inflate(R.layout.fragment_tab5,
                        container, false);
                spinner = rootView.findViewById(R.id.spinner5);
                listView = rootView.findViewById(R.id.listView5);
            case 6:
                rootView = inflater.inflate(R.layout.fragment_tab6,
                        container, false);
                spinner = rootView.findViewById(R.id.spinner6);
                listView = rootView.findViewById(R.id.listView6);
            case 7:
                rootView = inflater.inflate(R.layout.fragment_tab7,
                        container, false);
                spinner = rootView.findViewById(R.id.spinner7);
                listView = rootView.findViewById(R.id.listView7);
        }



        ArrayAdapter<String> myAdapter =
                new ArrayAdapter<String>(getContext(), R.layout.color_spinner_layout,
                        getResources().getStringArray(R.array.names));


        if(link3 == null || link3 == "") {
            myAdapter =
                    new ArrayAdapter<String>(getContext(), R.layout.color_spinner_layout,
                            getResources().getStringArray(R.array.names_2));
        }
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(myAdapter);



        mangDocBao = new ArrayList<Docbao>();


        com.example.app_doc_bao_bang_rss.ReadRSS readRSS =
                new com.example.app_doc_bao_bang_rss.ReadRSS(mangDocBao, listView, getContext());
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    com.example.app_doc_bao_bang_rss.ReadRSS readRSS =
                            new com.example.app_doc_bao_bang_rss.ReadRSS(mangDocBao, listView, getContext());
                    readRSS.execute(link1);

                }
                else if (position == 1) {
                    com.example.app_doc_bao_bang_rss.ReadRSS readRSS =
                            new com.example.app_doc_bao_bang_rss.ReadRSS(mangDocBao, listView, getContext());
                    readRSS.execute(link2);

                }
                else if (position == 2) {
                    com.example.app_doc_bao_bang_rss.ReadRSS readRSS =
                            new com.example.app_doc_bao_bang_rss.ReadRSS(mangDocBao, listView, getContext());
                    readRSS.execute(link3);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        if (listView != null)
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(getContext(), Main2Activity.class);
                    intent.putExtra("link", mangDocBao.get(position).link);
                    startActivity(intent);
                }
            });

        return rootView;

    }


}
