package com.example.app_doc_bao_bang_rss;

public class Docbao {
    public String title;
    public String link;
    public String imgae;
    public String pubDate;
    public Docbao(String title, String link, String imgae, String pubDate) {
        this.title = title;
        this.link = link;
        this.imgae = imgae;
        this.pubDate = pubDate;
    }
}
