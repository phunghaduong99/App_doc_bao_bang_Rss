package com.example.app_doc_bao_bang_rss;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import com.example.app_doc_bao_bang_rss.fragment.Tab1;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> arrayTitle;
    ArrayAdapter adapter;

    CusAdapter cusAdapter;
    ArrayList<Docbao> mangDocBao;

    Toolbar toolbar;
    private DrawerLayout drawerLayout;

    private ViewPager viewPager;
    private TabLayout tabLayout;

    private Tab1 tab1;
    private Tab1 tab2;
    private Tab1 tab3;
    private Tab1 tab4;
    private Tab1 tab5;
    private Tab1 tab6;
    private Tab1 tab7;
    private Tab1 tab8;
    private Tab1 tab9;
    private Tab1 tab10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        viewPager = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tab_layout);
        tab1 = new Tab1(
                "https://vnexpress.net/rss/tin-moi-nhat.rss",
                "https://tuoitre.vn/rss/tin-moi-nhat.rss",
                null,
                1);
        tab2 = new Tab1(
                "https://vnexpress.net/rss/the-gioi.rss",
                "https://tuoitre.vn/rss/the-gioi.rss",
                null,
                2);
        tab3 = new Tab1(
                "https://vnexpress.net/rss/thoi-su.rss",
                "https://tuoitre.vn/rss/thoi-su.rss",
                "https://cdn.24h.com.vn/upload/rss/anninhhinhsu.rss",
                3);
        tab4 = new Tab1(
                "https://vnexpress.net/rss/kinh-doanh.rss",
                "https://tuoitre.vn/rss/kinh-doanh.rss",
                "https://cdn.24h.com.vn/upload/rss/taichinhbatdongsan.rss",
                4);
        tab5 = new Tab1(
                "https://vnexpress.net/rss/giai-tri.rss",
                "https://tuoitre.vn/rss/giai-tri.rss",
                null,
                5);
        tab6 = new Tab1(
                "https://vnexpress.net/rss/the-thao.rss",
                "https://tuoitre.vn/rss/the-thao.rss",
                "https://cdn.24h.com.vn/upload/rss/thethao.rss",
                6);
        tab7 = new Tab1(
                "https://vnexpress.net/rss/phap-luat.rss",
                "https://tuoitre.vn/rss/phap-luat.rss",
                null,
                7);
//        tab5 = new Tab5();
//        tab6 = new Tab6();
//        tab7 = new Tab7();
//        tab8 = new Tab8();
//        tab9 = new Tab9();
//        tab10 = new Tab10();



        tabLayout.setupWithViewPager(viewPager);

        PagerAdapter pagerAdapter = new PagerAdapter(getSupportFragmentManager(), 0);
        pagerAdapter.addFragment(tab1, "Trang chủ");
        pagerAdapter.addFragment(tab2, "Thế giới");
        pagerAdapter.addFragment(tab3, "Thời sự");
        pagerAdapter.addFragment(tab4, "Kinh doanh");
        pagerAdapter.addFragment(tab5, "Giải trí");
        pagerAdapter.addFragment(tab6, "Thể thao");
        pagerAdapter.addFragment(tab7, "Pháp luật");
//        pagerAdapter.addFragment(tab8, "Giáo dục");
//        pagerAdapter.addFragment(tab9, "Sức khỏe");
//        pagerAdapter.addFragment(tab10, "Đời sống");
//        pagerAdapter.addFragment(tab3, "Du lịch");
//        pagerAdapter.addFragment(tab3, "Khoa học");
//        pagerAdapter.addFragment(tab3, "Công nghệ");
//        pagerAdapter.addFragment(tab3, "Xe");
//        pagerAdapter.addFragment(tab3, "Thư giãn");

        viewPager.setAdapter(pagerAdapter);


    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }

    }
}
